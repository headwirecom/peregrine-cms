var cmpAdminComponentsContentview = (function () {
'use strict';

var template = {render: function(){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"fullheight"},[_c('iframe',{staticStyle:{"padding-top":"2px"},attrs:{"id":"editview","src":"/content/sites/example.html","width":"100%","height":"100%","frameborder":"0"}})],1)},staticRenderFns: [],
    props: ['model']
};

return template;

}());
