var cmpAdminComponentsIconlist = (function () {
'use strict';

var template = {render: function(){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',[_vm._v("source of icon list; "+_vm._s(_vm.model.source))])},staticRenderFns: [],
    props: ['model']
};

return template;

}());
