var cmpAdminComponentsComponentlist = (function () {
'use strict';

var template = {render: function(){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',[_c('p',[_vm._v("components")]),_c('div',{staticClass:"card blue-grey darken-1",attrs:{"draggable":"true","ondragstart":_vm.onDragStart}},[_vm._m(0)])])},staticRenderFns: [function(){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"card-content white-text"},[_c('span',{staticClass:"card-title"},[_vm._v("text")]),_c('p',[_vm._v("text component - allows you to author rich text areas")])])}],
    props: ['model'],
    methods: {
        onDragStart: function(ev) {
            ev.dataTransfer.setData('component', this.model.path);
        }
    }
};

return template;

}());
