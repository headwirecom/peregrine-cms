<template>
    <div>
        <p>editor</p>
    </div>
</template>

<script>
    export default {
        props: ['model']

    }
</script>