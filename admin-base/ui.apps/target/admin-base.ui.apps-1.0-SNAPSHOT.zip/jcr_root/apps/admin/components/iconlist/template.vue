<template>
<div>
    source of icon list; {{model.source}}
</div>
</template>

<script>
    export default {
        props: ['model']
    }
</script>
