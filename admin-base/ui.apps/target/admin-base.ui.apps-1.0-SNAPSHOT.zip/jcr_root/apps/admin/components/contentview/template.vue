<template>
    <div class="fullheight">
        <iframe id="editview" src="/content/sites/example.html" width="100%" height="100%" frameborder="0" style="padding-top: 2px"></iframe>
    </div>
</template>

<script>
export default {
    props: ['model']
}
</script>